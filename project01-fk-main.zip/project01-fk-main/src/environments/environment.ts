export const environment = {
  api: {
    baseUrl: 'http://127.0.0.1:8000/', 
    persona: {
      persona: "persona"
    }
  },
  production: false
};